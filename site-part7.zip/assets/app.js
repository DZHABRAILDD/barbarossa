(() => {
  const onMenu = document.body.dataset.page === 'menu';
  const base = onMenu ? '../' : './';
  const footer = document.querySelector('footer');
  footer.innerHTML = `
    <a class="footer-logo" href="${base}" aria-label="BARBAROSSA, на главную">BARBAROSSA</a>
    <div class="footer-info"><small>© ${new Date().getFullYear()} BARBAROSSA</small>
      <a href="${base}assets/credits.json" target="_blank" rel="noopener">Источники фотографий</a>
    </div>
    <nav class="footer-actions" aria-label="Меню и телефон ресторана">
      <a class="footer-menu" href="${base}menu/">Меню</a>
      <a class="footer-phone" href="tel:+79030133395">+7 (903) 013-33-95</a>
    </nav>`;

  const reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      }
    }, {threshold: 0.08});
    reveals.forEach(element => observer.observe(element));
  } else {
    reveals.forEach(element => element.classList.add('visible'));
  }

  for (const dialog of document.querySelectorAll('dialog')) {
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const {left, right, top, bottom} = dialog.getBoundingClientRect();
      if (event.clientX < left || event.clientX > right || event.clientY < top || event.clientY > bottom) dialog.close();
    });
  }
})();
