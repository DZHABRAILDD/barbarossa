async function startMenu() {
  const find = selector => document.querySelector(selector);
  const escape = value => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[ch]));
  const rubles = new Intl.NumberFormat('ru-RU', {style:'currency', currency:'RUB', maximumFractionDigits:0});
  const plural = new Intl.PluralRules('ru');
  const dishWord = count => ({one:'блюдо', few:'блюда', many:'блюд', other:'блюд'}[plural.select(count)]);
  const price = value => rubles.format(value);
  const catalog = find('#dish-grid');
  const dishDialog = find('#dish-dialog');
  const selectionDialog = find('#selection-dialog');
  const selectedButton = find('#open-selection');
  const storageKey = 'barbarossa-table-v1';
  const maxQuantity = 30;
  let dishes;
  try {
    const response = await fetch('../assets/menu.json', {cache:'no-cache'});
    if (!response.ok) throw new Error('Menu unavailable');
    dishes = await response.json();
  } catch {
    catalog.innerHTML = '<p>Не удалось загрузить меню. <a href="">Обновить страницу</a></p>';
    return;
  }

  const byId = new Map(dishes.map(dish => [dish.id, dish]));
  const categories = ['Все', ...new Set(dishes.map(dish => dish.category))];
  const params = new URLSearchParams(location.search);
  let activeCategory = categories.includes(params.get('category')) ? params.get('category') : 'Все';
  let activeDish;
  let variant = 0;
  let quantity = 1;
  let toastTimer;
  let selection = restoreSelection();

  function restoreSelection() {
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || '[]');
      return saved.filter(item => {
        const dish = byId.get(item?.id);
        return dish && Number.isInteger(item.variant) && item.variant >= 0 && item.variant < dish.prices_rub.length &&
          Number.isInteger(item.qty) && item.qty >= 1 && item.qty <= maxQuantity;
      });
    } catch {
      return [];
    }
  }

  function displaySelectionCount() {
    const count = selection.reduce((total, item) => total + item.qty, 0);
    
    selectedButton.textContent = `Корзина${count ? ' · ' + count : ''}`;
    selectedButton.setAttribute('aria-label', `Корзина. Порций: ${count}`);
  }

  function persistSelection() {
    try {
      localStorage.setItem(storageKey, JSON.stringify(selection));
    } catch {
      // A visitor can still use the selection with storage disabled.
    }
    displaySelectionCount();
  }

  function announce(message) {
    const toast = find('.toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2300);
  }

  function renderCards() {
    const search = find('#search').value.trim().toLocaleLowerCase('ru');
    const filtered = dishes.filter(dish => {
      const text = [dish.name, dish.description, ...(dish.ingredients || [])].join(' ').toLocaleLowerCase('ru');
      return (activeCategory === 'Все' || dish.category === activeCategory) && text.includes(search);
    });
    find('#result-count').textContent = `${filtered.length} ${dishWord(filtered.length)}`;
    find('#empty').hidden = filtered.length !== 0;
    catalog.innerHTML = filtered.map(dish => {
      const name = escape(dish.name);
      const id = escape(dish.id);
      const photo = `../assets/images/${encodeURIComponent(dish.photo_key)}`;
      const original = dish.original_primary && dish.original_photo;
      const src = original ? '../' + escape(dish.original_photo) : photo + '.webp';
      const responsive = original ? '' : `srcset="${photo}-1200.webp 1200w, ${photo}.webp 2000w, ${photo}-4k.webp 3840w"`;
      const alt = dish.name;
      const displayPrice = (dish.prices_rub.length > 1 ? 'от ' : '') + price(Math.min(...dish.prices_rub));
      return `<article class="dish-card">
        <button type="button" class="dish-image" data-dish="${id}" aria-label="Подробнее: ${name}">
          <img src="${src}" ${responsive} class="${original ? 'original-source' : ''}"
               sizes="(max-width:650px) 100vw, (max-width:1050px) 50vw, 33vw" loading="lazy" decoding="async"
               alt="${escape(alt)}">
        </button>
        <div class="card-copy">
          <h2><button type="button" class="dish-name" data-dish="${id}">${name}</button></h2>
          <p>${escape(dish.description)}</p>
          <div class="card-order"><strong>${displayPrice}</strong>
            <button type="button" class="dish-plus" data-dish="${id}" aria-label="Выбрать порцию: ${name}">+</button>
          </div>
        </div>
      </article>`;
    }).join('');
    for (const button of find('#categories').querySelectorAll('button')) {
      button.setAttribute('aria-pressed', String(button.dataset.category === activeCategory));
    }
  }

  function portionName(dish, index) {
    return dish.portion_labels?.[index] || (dish.prices_rub.length === 1 ? 'Одна порция' : `Вариант ${index + 1}`);
  }

  function updatePortion() {
    const savedQuantity = selection.find(item => item.id === activeDish.id && item.variant === variant)?.qty || 0;
    const available = maxQuantity - savedQuantity;
    quantity = available > 0 ? Math.min(quantity, available) : 0;
    find('#portion-minus').disabled = quantity < 2;
    find('#portion-plus').disabled = quantity >= available;
    find('#portion-count').textContent = quantity;
    find('#dialog-add').disabled = !available;
    find('#portion-total').textContent = available ? price(activeDish.prices_rub[variant] * quantity) : 'Уже выбрано 30 порций';
  }

  function openDish(dish) {
    activeDish = dish;
    variant = 0;
    quantity = 1;
    const photo = find('#detail-photo');
    photo.src = dish.original_primary && dish.original_photo ? '../' + dish.original_photo : `../assets/images/${encodeURIComponent(dish.photo_key)}-4k.webp`;
    photo.alt = dish.name;
    find('#detail-category').textContent = dish.category;
    find('#dish-title').textContent = dish.name;
    find('#dish-ingredients').textContent = dish.ingredients?.join(', ') || dish.description;
    find('#portion-options').innerHTML = dish.prices_rub.map((value, index) => `
      <label class="portion-choice">
        <input type="radio" name="portion" value="${index}" ${index === 0 ? 'checked' : ''}>
        <span>${escape(portionName(dish, index))}</span><strong>${price(value)}</strong>
      </label>`).join('');
    updatePortion();
    dishDialog.showModal();
    dishDialog.scrollTop = 0;
  }

  function renderSelection() {
    const empty = selection.length === 0;
    find('.selection-total').hidden = empty;
    find('#share-selection').hidden = empty;
    if (empty) {
      find('#selection-list').innerHTML = '<li>Корзина пока пуста.</li>';
      return;
    }
    let total = 0;
    const lines = [];
    find('#selection-list').innerHTML = selection.map((item, index) => {
      const dish = byId.get(item.id);
      const amount = dish.prices_rub[item.variant] * item.qty;
      total += amount;
      const label = portionName(dish, item.variant);
      lines.push(`${dish.name}, ${label} × ${item.qty} — ${price(amount)}`);
      return `<li>
        <div class="selection-name"><strong>${escape(dish.name)}</strong><small>${escape(label)} · ${price(amount)}</small></div>
        <div class="counter">
          <button type="button" data-line="${index}" data-step="-1" aria-label="Убрать порцию: ${escape(dish.name)}">−</button>
          <span>${item.qty}</span>
          <button type="button" data-line="${index}" data-step="1" aria-label="Ещё порция: ${escape(dish.name)}" ${item.qty >= maxQuantity ? 'disabled' : ''}>+</button>
        </div>
      </li>`;
    }).join('');
    find('#selection-total').textContent = price(total);
    const message = ['Здравствуйте! Хочу заказать в BARBAROSSA:', ...lines, `Итого: ${price(total)}.`].join('\n');
    find('#share-selection').href = 'https://wa.me/79030133395?text=' + encodeURIComponent(message);
  }

  find('#categories').innerHTML = categories.map(category =>
    `<button type="button" data-category="${escape(category)}">${escape(category)}</button>`).join('');
  find('#categories').addEventListener('click', event => {
    const button = event.target.closest('[data-category]');
    if (!button) return;
    activeCategory = button.dataset.category;
    renderCards();
  });
  find('#search').addEventListener('input', renderCards);
  find('#reset').addEventListener('click', () => {
    activeCategory = 'Все';
    find('#search').value = '';
    renderCards();
    find('#search').focus();
  });
  catalog.addEventListener('click', event => {
    const button = event.target.closest('[data-dish]');
    if (button) openDish(byId.get(button.dataset.dish));
  });
  find('#portion-options').addEventListener('change', event => {
    variant = Number(event.target.value);
    quantity = Math.max(1, quantity);
    updatePortion();
  });
  find('#portion-minus').addEventListener('click', () => { quantity--; updatePortion(); });
  find('#portion-plus').addEventListener('click', () => { quantity++; updatePortion(); });
  find('#portion-form').addEventListener('submit', event => {
    event.preventDefault();
    if (!quantity) return;
    const existing = selection.find(item => item.id === activeDish.id && item.variant === variant);
    if (existing) existing.qty = Math.min(existing.qty + quantity, maxQuantity);
    else selection.push({id:activeDish.id, variant, qty:quantity});
    persistSelection();
    dishDialog.close();
    announce(`${activeDish.name} · добавлено в корзину`);
  });
  selectedButton.addEventListener('click', () => {
    renderSelection();
    selectionDialog.showModal();
  });
  find('#selection-list').addEventListener('click', event => {
    const button = event.target.closest('[data-step]');
    if (!button) return;
    const index = Number(button.dataset.line);
    const item = selection[index];
    item.qty += Number(button.dataset.step);
    if (item.qty < 1) selection.splice(index, 1);
    persistSelection();
    renderSelection();
    if (selectionDialog.open) {
      const focusLine = Math.min(index, selection.length - 1);
      const next = selectionDialog.querySelector(`[data-line="${focusLine}"][data-step="${button.dataset.step}"]:enabled`)
        || selectionDialog.querySelector(`[data-line="${focusLine}"]:enabled`);
      next?.focus({preventScroll:true});
    }
  });
  for (const button of document.querySelectorAll('[data-close]')) {
    button.addEventListener('click', () => button.closest('dialog').close());
  }
  renderCards();
  displaySelectionCount();
  if (params.has('table') && selection.length) selectedButton.click();
}

startMenu();

